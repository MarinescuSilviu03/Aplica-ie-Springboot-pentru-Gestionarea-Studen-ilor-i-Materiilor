package com.example.demo.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import java.util.Set;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
@Entity
@Table(name = "subjects")

public class Subjects {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idsubjects;
	@Column(name = "denumire_subject", nullable = false)
	private String denumire_subject;
	@Column(name = "an_predare")
	private Long an_predare;
	@Column(name = "semestru_predare")
	private Long semestru_predare;
	@Column(name = "puncte_credit")
	private Long puncte_credit;
	@Column(name = "profesor")
	private String profesor;	
	@ManyToOne()
	@JoinColumn(name = "idserie", nullable = false)
	private Serie serie;
	
	public Subjects() {
	}
	public Subjects(String denumire_subject, Long an_predare,Long semestru_predare,Long puncte_credit,String profesor,Serie serie) {
	super();
	this.denumire_subject = denumire_subject;
	this.an_predare = an_predare;
	this.semestru_predare = semestru_predare;
	this.puncte_credit = puncte_credit;
	this.profesor = profesor;
	this.serie = serie;
	}
	public Long getIdsubjects() {
	return idsubjects;
	}
	public void setIdsubjects(Long idsubjects) {
	this.idsubjects = idsubjects;
	}
	public String getDenumire_subject() {
	return denumire_subject;
	}
	public void setDenumire_subject(String denumire_subject) {
	this.denumire_subject = denumire_subject;
	}
	public Long getAn_predare() {
	return an_predare;
	}
	public void setAn_predare(Long an_predare) {
	this.an_predare = an_predare;
	}
	public Long getSemestru_predare() {
	return semestru_predare;
	}
	public void setSemestru_predare(Long semestru_predare) {
	this.semestru_predare = semestru_predare;
	}
	public Long getPuncte_credit() {
	return puncte_credit;
	}
	public void setPuncte_credit(Long puncte_credit) {
	this.puncte_credit = puncte_credit;
	}
	public Serie getSerie() {
	return serie;
	}
	public void setSerie(Serie serie) {
	this.serie = serie;
	}
	public String getProfesor() {
	return profesor;
	}
	public void setProfesor(String profesor) {
	this.profesor = profesor;
	}

}
