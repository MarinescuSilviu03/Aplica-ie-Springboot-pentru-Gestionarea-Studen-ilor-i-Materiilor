package com.example.demo.service;
import java.util.List;

import com.example.demo.entity.Students;
public interface StudentsService {
List<Students> getAllStudents();
Students saveStudents(Students students);
Students getStudentsById(Long idstudents);
Students updateStudents(Students students);
void deleteStudentsById(Long idstudents);
}
