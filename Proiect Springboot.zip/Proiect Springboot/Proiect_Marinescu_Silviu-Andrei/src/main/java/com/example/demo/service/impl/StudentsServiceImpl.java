package com.example.demo.service.impl;
import java.util.List;

import org.springframework.stereotype.Service;
import com.example.demo.entity.Students;
import com.example.demo.repository.StudentsRepository;
import com.example.demo.service.StudentsService;
@Service
public class StudentsServiceImpl implements StudentsService{
private StudentsRepository StudentsRepository;
public StudentsServiceImpl(StudentsRepository StudentsRepository) {
super();
this.StudentsRepository = StudentsRepository;
}
@Override
public List<Students> getAllStudents() {
return StudentsRepository.findAll();
}
@Override
public Students saveStudents(Students Students) {
return StudentsRepository.save(Students);
}
@Override
public Students getStudentsById(Long idstudents) {
return StudentsRepository.findById(idstudents).get();
}
@Override
public Students updateStudents(Students Students) {
return StudentsRepository.save(Students);
}
@Override
public void deleteStudentsById(Long idstudents) {
	StudentsRepository.deleteById(idstudents);
}
}
