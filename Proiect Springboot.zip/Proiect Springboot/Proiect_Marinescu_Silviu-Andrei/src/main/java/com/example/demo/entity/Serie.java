package com.example.demo.entity;


import java.util.Set;

import jakarta.persistence.*;
@Entity
@Table(name = "serie")
public class Serie {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idserie;
	@Column(name = "denumire_serie", nullable = false)
	private String denumire_serie;
	@Column(name = "numar_grupe")
	private Long numar_grupe;
	@Column(name = "numar_studenti")
	private Long numar_studenti;
	
	public Serie() {
	}
	public Serie(String denumire_serie, Long numar_grupe, Long numar_studenti) {
	super();
	this.denumire_serie = denumire_serie;
	this.numar_grupe = numar_grupe;
	this.numar_studenti = numar_studenti;
	}
	public Long getIdserie() {
	return idserie;
	}
	public void setIdserie(Long idserie) {
	this.idserie = idserie;
	}
	public String getDenumire_serie() {
	return denumire_serie;
	}
	public void setDenumire_serie(String denumire_serie) {
	this.denumire_serie = denumire_serie;
	}
	public Long getNumar_grupe() {
	return numar_grupe;
	}
	public void setNumar_grupe(Long numar_grupe) {
	this.numar_grupe = numar_grupe;
	}
	public Long getNumar_studenti() {
	return numar_studenti;
	}
	public void setNumar_studenti(Long numar_studenti) {
	this.numar_studenti = numar_studenti;
	}
}
