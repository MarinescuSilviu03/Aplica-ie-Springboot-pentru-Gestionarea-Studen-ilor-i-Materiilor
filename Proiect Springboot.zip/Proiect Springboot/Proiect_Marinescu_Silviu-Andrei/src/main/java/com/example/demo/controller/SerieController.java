package com.example.demo.controller;
import org.springframework.stereotype.Controller;



import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.entity.Serie;
import com.example.demo.service.SerieService;

@Controller
public class SerieController {
private SerieService serieService;
public SerieController(SerieService serieService) {
super();
this.serieService = serieService;
}
@GetMapping("/serie")
public String listSerie(Model model) {
model.addAttribute("serie", serieService.getAllSerie());
return "serie";
}
@GetMapping("/serie/new")
public String createSerieForm(Model model) {
	Serie serie = new Serie();
model.addAttribute("serie", serie);
return "create_serie";
}
@PostMapping("/serie")
public String saveSerie(@ModelAttribute("serie") Serie serie) {
	serieService.saveSerie(serie);
return "redirect:/serie";
}
@GetMapping("/serie/edit/{idserie}")
public String editSerieForm(@PathVariable Long idserie, Model model) {
model.addAttribute("serie", serieService.getSerieById(idserie));
return "edit_serie";
}
@PostMapping("/serie/{idserie}")
public String updateSerie(@PathVariable Long idserie,
@ModelAttribute("serie") Serie serie,Model model) {
	Serie serieExistent = serieService.getSerieById(idserie);
	serieExistent.setIdserie(idserie);
	serieExistent.setDenumire_serie(serie.getDenumire_serie());
	serieExistent.setNumar_grupe(serie.getNumar_grupe());
	serieExistent.setNumar_studenti(serie.getNumar_studenti());
serieService.updateSerie(serieExistent);
return "redirect:/serie";
}
@GetMapping("/serie/{idserie}")
public String deleteSerie(@PathVariable Long idserie) {
	serieService.deleteSerieById(idserie);
return "redirect:/serie";
}
}