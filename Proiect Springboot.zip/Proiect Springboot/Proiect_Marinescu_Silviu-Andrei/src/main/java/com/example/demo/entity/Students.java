package com.example.demo.entity;

import java.util.Set;
import java.sql.Date;

import jakarta.persistence.*;
@Entity
@Table(name = "students")

public class Students {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idstudents;
	@Column(name = "nume", nullable = false)
	private String nume;
	@Column(name = "prenume")
	private String prenume;
	@Column(name = "cnp")
	private Long cnp;
	@Column(name = "adresa")
	private String adresa;
	@Column(name = "numartelefon")
	private String numartelefon;
	@Column(name = "data_nastere")
	private Date data_nastere;
	@Column(name = "an_curent")
	private Long an_curent;
	@Column(name = "medie")
	private Long medie;
	@ManyToOne()
	@JoinColumn(name = "idserie", nullable = false)
	private Serie serie;
	
	public Students() {
	}
	public Students(String nume, String prenume, Long cnp,String adresa,String numartelefon,Date data_nastere,Serie serie,Long an_curent,Long medie) {
	super();
	this.nume = nume;
	this.prenume = prenume;
	this.cnp = cnp;
	this.adresa = adresa;
	this.numartelefon = numartelefon;
	this.data_nastere = data_nastere;
	this.serie = serie;
	this.an_curent = an_curent;
	this.medie = medie;
	}
	public Long getIdstudents() {
	return idstudents;
	}
	public void setIdstudents(Long idstudents) {
	this.idstudents = idstudents;
	}
	public String getNume() {
	return nume;
	}
	public void setNume(String nume) {
	this.nume = nume;
	}
	public String getPrenume() {
	return prenume;
	}
	public void setPrenume(String prenume) {
	this.prenume = prenume;
	}
	public String getAdresa() {
	return adresa;
	}
	public void setAdresa(String adresa) {
	this.adresa = adresa;
	}
	public String getNumartelefon() {
	return numartelefon;
	}
	public void setNumartelefon(String numartelefon) {
	this.numartelefon = numartelefon;
	}
	public Date getData_nastere() {
	return data_nastere;
	}
	public void setData_nastere(Date data_nastere) {
	this.data_nastere = data_nastere;
	}
	public Serie getSerie() {
	return serie;
	}
	public void setSerie(Serie serie) {
	this.serie = serie;
	}
	public Long getCnp() {
	return cnp;
	}
	public void setCnp(Long cnp) {
	this.cnp = cnp;
	}
	public Long getAn_curent() {
	return an_curent;
	}
	public void setAn_curent(Long an_curent) {
	this.an_curent = an_curent;
	}
	public Long getMedie() {
	return medie;
	}
	public void setMedie(Long medie) {
	this.medie = medie;
	}
}
