package com.example.demo.service;
import java.util.List;

import com.example.demo.entity.Subjects;
public interface SubjectsService {
List<Subjects> getAllSubjects();
Subjects saveSubjects(Subjects subjects);
Subjects getSubjectsById(Long idsubjects);
Subjects updateSubjects(Subjects subjects);
void deleteSubjectsById(Long idsubjects);
}
