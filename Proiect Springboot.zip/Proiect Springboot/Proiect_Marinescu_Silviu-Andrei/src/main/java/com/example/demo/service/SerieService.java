package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Serie;

public interface SerieService {
List<Serie> getAllSerie();
Serie saveSerie(Serie serie);
Serie getSerieById(Long idserie);
Serie updateSerie(Serie serie);
void deleteSerieById(Long idserie);
}