package com.example.demo.service.impl;
import java.util.List;


import org.springframework.stereotype.Service;

import com.example.demo.entity.Serie;
import com.example.demo.repository.SerieRepository;
import com.example.demo.service.SerieService;
@Service
public class SerieServiceImpl implements SerieService{
private SerieRepository SerieRepository;
public SerieServiceImpl(SerieRepository SerieRepository) {
super();
this.SerieRepository = SerieRepository;
}
@Override
public List<Serie> getAllSerie() {
return SerieRepository.findAll();
}
@Override
public Serie saveSerie(Serie Serie) {
return SerieRepository.save(Serie);
}
@Override
public Serie getSerieById(Long idserie) {
return SerieRepository.findById(idserie).get();
}
@Override
public Serie updateSerie(Serie Serie) {
return SerieRepository.save(Serie);
}
@Override
public void deleteSerieById(Long idserie) {
	SerieRepository.deleteById(idserie);
}
}
