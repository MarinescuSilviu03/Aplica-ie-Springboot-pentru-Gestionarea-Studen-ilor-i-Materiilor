package com.example.demo.service.impl;
import java.util.List;

import org.springframework.stereotype.Service;
import com.example.demo.entity.Subjects;
import com.example.demo.repository.SubjectsRepository;
import com.example.demo.service.SubjectsService;
@Service
public class SubjectsServiceImpl implements SubjectsService{
private SubjectsRepository SubjectsRepository;
public SubjectsServiceImpl(SubjectsRepository SubjectsRepository) {
super();
this.SubjectsRepository = SubjectsRepository;
}
@Override
public List<Subjects> getAllSubjects() {
return SubjectsRepository.findAll();
}
@Override
public Subjects saveSubjects(Subjects Subjects) {
return SubjectsRepository.save(Subjects);
}
@Override
public Subjects getSubjectsById(Long idsubjects) {
return SubjectsRepository.findById(idsubjects).get();
}
@Override
public Subjects updateSubjects(Subjects Subjects) {
return SubjectsRepository.save(Subjects);
}
@Override
public void deleteSubjectsById(Long idsubjects) {
	SubjectsRepository.deleteById(idsubjects);
}
}