package com.example.demo.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;


import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.entity.Serie;
import com.example.demo.entity.Students;
import com.example.demo.repository.SerieRepository;
import com.example.demo.service.StudentsService;
@Controller
public class StudentsController {
private StudentsService studentsService;

@Autowired
private SerieRepository serieRepo;


public StudentsController(StudentsService studentsService) {
super();
this.studentsService = studentsService;
}
@GetMapping("/students")
public String listStudents(Model model) {
model.addAttribute("students", studentsService.getAllStudents());
return "students";
}
@GetMapping("/students/new")
public String createStudentsForm(Model model) {
List<Serie> totiserie = serieRepo.findAll();
Students students = new Students();
model.addAttribute("students", students);
model.addAttribute("totiserie", totiserie);
return "create_students";
}
@PostMapping("/students")
public String saveStudents(@ModelAttribute("students") Students students) {
	studentsService.saveStudents(students);
return "redirect:/students";
}
@GetMapping("/students/edit/{idstudents}")
public String editStudentsForm(@PathVariable Long idstudents, Model model) {
	List<Serie> totiserie = serieRepo.findAll();
model.addAttribute("students", studentsService.getStudentsById(idstudents));
model.addAttribute("totiserie", totiserie);
return "edit_students";
}
@PostMapping("/students/{idstudents}")
public String updateStudents(@PathVariable Long idstudents,
@ModelAttribute("students") Students students,Model model) {
	Students studentsExistent = studentsService.getStudentsById(idstudents);
	studentsExistent.setIdstudents(idstudents);
	studentsExistent.setNume(students.getNume());
	studentsExistent.setPrenume(students.getPrenume());
	studentsExistent.setCnp(students.getCnp());
	studentsExistent.setAdresa(students.getAdresa());
	studentsExistent.setNumartelefon(students.getNumartelefon());
	studentsExistent.setData_nastere(students.getData_nastere());
	studentsExistent.setSerie(students.getSerie());
	studentsExistent.setAn_curent(students.getAn_curent());
	studentsExistent.setMedie(students.getMedie());
	studentsService.updateStudents(studentsExistent);
return "redirect:/students";
}

@GetMapping("/students/{idstudents}")
public String deleteStudents(@PathVariable Long idstudents) {
	studentsService.deleteStudentsById(idstudents);
return "redirect:/students";
}
}