package com.example.demo.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;


import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.entity.Serie;
import com.example.demo.entity.Subjects;
import com.example.demo.repository.SerieRepository;
import com.example.demo.service.SubjectsService;
@Controller
public class SubjectsController {
private SubjectsService subjectsService;

@Autowired
private SerieRepository serieRepo;


public SubjectsController(SubjectsService subjectsService) {
super();
this.subjectsService = subjectsService;
}
@GetMapping("/subjects")
public String listSubjects(Model model) {
model.addAttribute("subjects", subjectsService.getAllSubjects());
return "subjects";
}
@GetMapping("/subjects/new")
public String createSubjectsForm(Model model) {
	List<Serie> totiserie = serieRepo.findAll();
	Subjects subjects = new Subjects();
model.addAttribute("subjects", subjects);
model.addAttribute("totiserie", totiserie);
return "create_subjects";
}
@PostMapping("/subjects")
public String saveSubjects(@ModelAttribute("subjects") Subjects subjects) {
	subjectsService.saveSubjects(subjects);
return "redirect:/subjects";
}
@GetMapping("/subjects/edit/{idsubjects}")
public String editSubjectsForm(@PathVariable Long idsubjects, Model model) {
	List<Serie> totiserie = serieRepo.findAll();
model.addAttribute("subjects", subjectsService.getSubjectsById(idsubjects));
model.addAttribute("totiserie", totiserie);
return "edit_subjects";
}
@PostMapping("/subjects/{idsubjects}")
public String updateSubjects(@PathVariable Long idsubjects,
@ModelAttribute("subjects") Subjects subjects,Model model) {
	Subjects subjectsExistent = subjectsService.getSubjectsById(idsubjects);
	subjectsExistent.setIdsubjects(idsubjects);
	subjectsExistent.setDenumire_subject(subjects.getDenumire_subject());
	subjectsExistent.setAn_predare(subjects.getAn_predare());
	subjectsExistent.setSemestru_predare(subjects.getSemestru_predare());
	subjectsExistent.setPuncte_credit(subjects.getPuncte_credit());
	subjectsExistent.setProfesor(subjects.getProfesor());
	subjectsExistent.setSerie(subjects.getSerie());
	subjectsService.updateSubjects(subjectsExistent);
return "redirect:/subjects";
}
@GetMapping("/subjects/{idsubjects}")
public String deleteSubjects(@PathVariable Long idsubjects) {
	subjectsService.deleteSubjectsById(idsubjects);
return "redirect:/subjects";
}
}